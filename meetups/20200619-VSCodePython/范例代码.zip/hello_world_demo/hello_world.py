'''
@Author: your name
@Date: 2020-06-14 16:32:27
@LastEditTime: 2020-06-19 20:46:37
@LastEditors: Please set LastEditors
@Description: In User Settings EditP
@FilePath: \hello_world_demo\hello_world.py
'''
import math
import os
import sys

import numpy as np
import requests

import debug_demo

a = np.ndarray([1, 1, 1])
print(type(a))


#ctrl+shitf+2
def hello_world(a, b):

    c = a + b
    print(c)
    return c



# 多光标/Pylint/Intellisense/运行代码块
# print "hello"
print("hello")
print(math.pi)
print(sys.version)

# 移动代码块/for loop/提取method

def my_func():
    for i in range(10):
        a = 0
        # ctrl+[
        a += i
        b = a * 2
        print(b)

my_func()


# 自动格式化代码：shift+alt+f
# 多光标：alt+鼠标左键
# 多光标：ctrl+f2
def exchange(root, base):
    m = root
    root = base
    base = m
    return (root, base)


root = 1
base = 2
print(exchange(root, base))

# 自动补全路径
# path =
