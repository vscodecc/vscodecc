import requests

# 查看定义
r = requests.get("http://www.baidu.com")

print(r.status_code)

